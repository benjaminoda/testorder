import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { CheckCircle, AlertCircle, Package, Building, Calculator, Minus, Plus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

const orderFormSchema = z.object({
  storeName: z.string().min(1, "Store name is required"),
  buyerName: z.string().min(1, "Buyer name is required"),
  contactEmail: z.string().email("Valid email is required"),
  contactPhone: z.string().min(1, "Phone number is required"),
  addr1: z.string().min(1, "Address is required"),
  addr2: z.string().optional(),
  city: z.string().min(1, "City is required"),
  state: z.string().length(2, "State must be 2 characters"),
  zip: z.string().min(5, "ZIP code is required"),
  paymentTerms: z.string().min(1, "Payment terms are required"),
  retailerCode: z.string().optional(),
  deliveryDate: z.string().optional(),
  windowStart: z.string().optional(),
  windowEnd: z.string().optional(),
  deliveryNotes: z.string().optional(),
});

type OrderFormData = z.infer<typeof orderFormSchema>;

interface QuantityState {
  [sku: string]: number;
}

const TAX_RATE = 0.0825;

export default function OrderForm() {
  const { toast } = useToast();
  const [quantities, setQuantities] = useState<QuantityState>({});
  const [orderSubmitted, setOrderSubmitted] = useState(false);
  const [orderId, setOrderId] = useState<string>("");

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderFormSchema),
    defaultValues: {
      storeName: "",
      buyerName: "",
      contactEmail: "",
      contactPhone: "",
      addr1: "",
      addr2: "",
      city: "",
      state: "",
      zip: "",
      paymentTerms: "",
      retailerCode: "",
      deliveryDate: "",
      windowStart: "",
      windowEnd: "",
      deliveryNotes: "",
    },
  });

  // Fetch products
  const { data: products, isLoading: productsLoading, error: productsError } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Handle URL prefill parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Check for token-based prefill
    const token = urlParams.get('t');
    if (token) {
      // TODO: Implement token-based prefill
      fetch(`/api/prefill?t=${encodeURIComponent(token)}`)
        .then(res => res.ok ? res.json() : Promise.reject(res.statusText))
        .then(data => {
          if (data) {
            if (data.storeName) form.setValue('storeName', data.storeName);
            if (data.buyer) form.setValue('buyerName', data.buyer);
            if (data.email) form.setValue('contactEmail', data.email);
            if (data.phone) form.setValue('contactPhone', data.phone);
            if (data.address) {
              if (data.address.line1) form.setValue('addr1', data.address.line1);
              if (data.address.line2) form.setValue('addr2', data.address.line2);
              if (data.address.city) form.setValue('city', data.address.city);
              if (data.address.state) form.setValue('state', data.address.state);
              if (data.address.zip) form.setValue('zip', data.address.zip);
            }
            if (data.terms) form.setValue('paymentTerms', data.terms);
            if (data.code) form.setValue('retailerCode', data.code);
          }
        })
        .catch(err => console.warn('Prefill token fetch failed:', err));
    } else {
      // Handle direct URL parameter prefill
      const paramMappings = {
        storename: 'storeName',
        buyer: 'buyerName',
        email: 'contactEmail',
        phone: 'contactPhone',
        addr1: 'addr1',
        addr2: 'addr2',
        city: 'city',
        state: 'state',
        zip: 'zip',
        terms: 'paymentTerms',
        store: 'retailerCode'
      };

      Object.entries(paramMappings).forEach(([urlParam, fieldName]) => {
        const value = urlParams.get(urlParam);
        if (value) {
          form.setValue(fieldName as keyof OrderFormData, decodeURIComponent(value));
        }
      });
    }
  }, [form]);

  // Order submission mutation
  const submitOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest('POST', '/api/order/submit', orderData);
      return response.json();
    },
    onSuccess: (data) => {
      setOrderId(data.orderId || generateOrderId());
      setOrderSubmitted(true);
      toast({
        title: "Order Submitted Successfully",
        description: "Your order has been received and will be processed within 24 hours.",
      });
      // Clear quantities
      setQuantities({});
    },
    onError: (error) => {
      toast({
        title: "Order Submission Failed",
        description: error.message || "Please check your information and try again.",
        variant: "destructive",
      });
    },
  });

  const generateOrderId = () => {
    return 'ORD-' + Date.now().toString().slice(-6) + '-' + Math.floor(Math.random() * 1000);
  };

  // Calculate pricing
  const calculatePricing = () => {
    if (!products) return { subtotal: 0, discounts: 0, tax: 0, total: 0 };

    let subtotal = 0;
    let originalTotal = 0;

    products.forEach(product => {
      const quantity = quantities[product.sku] || 0;
      if (quantity > 0) {
        const basePrice = parseFloat(product.basePrice);
        let unitPrice = basePrice;

        // Apply tier pricing
        if (product.tierPricing && Array.isArray(product.tierPricing)) {
          const tiers = product.tierPricing as { minQuantity: number; price: string }[];
          for (const tier of tiers.sort((a, b) => b.minQuantity - a.minQuantity)) {
            if (quantity >= tier.minQuantity) {
              unitPrice = parseFloat(tier.price);
              break;
            }
          }
        }

        subtotal += quantity * unitPrice;
        originalTotal += quantity * basePrice;
      }
    });

    const discounts = originalTotal - subtotal;
    const tax = subtotal * TAX_RATE;
    const total = subtotal + tax;

    return { subtotal, discounts, tax, total };
  };

  const { subtotal, discounts, tax, total } = calculatePricing();

  // Quantity handlers
  const updateQuantity = (sku: string, newQuantity: number) => {
    setQuantities(prev => ({
      ...prev,
      [sku]: Math.max(0, Math.min(999, newQuantity))
    }));
  };

  const incrementQuantity = (sku: string) => {
    updateQuantity(sku, (quantities[sku] || 0) + 1);
  };

  const decrementQuantity = (sku: string) => {
    updateQuantity(sku, (quantities[sku] || 0) - 1);
  };

  // Check if tier discount applies
  const getTierDiscount = (product: Product) => {
    const quantity = quantities[product.sku] || 0;
    if (!product.tierPricing || !Array.isArray(product.tierPricing) || quantity === 0) return null;

    const tiers = product.tierPricing as { minQuantity: number; price: string }[];
    for (const tier of tiers.sort((a, b) => b.minQuantity - a.minQuantity)) {
      if (quantity >= tier.minQuantity) {
        return tier;
      }
    }
    return null;
  };

  const onSubmit = async (data: OrderFormData) => {
    // Check if any products are ordered
    const hasProducts = Object.values(quantities).some(qty => qty > 0);
    if (!hasProducts) {
      toast({
        title: "No Products Selected",
        description: "Please select at least one product to order.",
        variant: "destructive",
      });
      return;
    }

    // Build order items
    const items = products?.filter(product => quantities[product.sku] > 0).map(product => {
      const quantity = quantities[product.sku];
      const tierDiscount = getTierDiscount(product);
      const unitPrice = tierDiscount ? parseFloat(tierDiscount.price) : parseFloat(product.basePrice);
      const lineTotal = quantity * unitPrice;

      return {
        sku: product.sku,
        name: product.name,
        qtyTrays: quantity,
        unitTray: unitPrice,
        lineTotal
      };
    }) || [];

    const orderData = {
      orderId: generateOrderId(),
      storeId: data.storeName.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12) + '-' + data.zip,
      storeName: data.storeName,
      buyerName: data.buyerName,
      contactEmail: data.contactEmail,
      contactPhone: data.contactPhone,
      addr1: data.addr1,
      addr2: data.addr2 || "",
      city: data.city,
      state: data.state,
      zip: data.zip,
      paymentTerms: data.paymentTerms,
      retailerCode: data.retailerCode || "",
      deliveryDate: data.deliveryDate || "",
      windowStart: data.windowStart || "",
      windowEnd: data.windowEnd || "",
      deliveryNotes: data.deliveryNotes || "",
      items,
      subtotal: subtotal.toFixed(2),
      tax: tax.toFixed(2),
      total: total.toFixed(2),
      totalTrays: Object.values(quantities).reduce((sum, qty) => sum + qty, 0),
      channel: 'Web-Form'
    };

    submitOrderMutation.mutate(orderData);
  };

  const clearForm = () => {
    form.reset();
    setQuantities({});
    setOrderSubmitted(false);
    setOrderId("");
  };

  if (orderSubmitted) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-card border-b border-border shadow-sm">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">E</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-foreground">Easies Order System</h1>
                  <p className="text-muted-foreground text-sm">Professional Retailer Portal</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8 max-w-4xl">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-4 mb-6">
                <CheckCircle className="w-12 h-12 text-green-600" />
                <div>
                  <h2 className="text-2xl font-bold text-green-800">Order Submitted Successfully</h2>
                  <p className="text-green-700">Your order has been received and will be processed within 24 hours.</p>
                </div>
              </div>
              
              {orderId && (
                <div className="bg-white rounded-lg p-4 border border-green-200 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-green-800">Order ID:</span>
                    <span className="font-bold text-green-900 text-lg">{orderId}</span>
                  </div>
                </div>
              )}

              <div className="flex gap-4">
                <Button onClick={clearForm} variant="outline" data-testid="button-new-order">
                  Place New Order
                </Button>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (productsError) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl font-bold text-gray-900">Error Loading Products</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              Unable to load product catalog. Please refresh the page or contact support.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xl">E</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Easies Order System</h1>
                <p className="text-muted-foreground text-sm">Professional Retailer Portal</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm">Secure Ordering</span>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            
            {/* Retailer Information */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <Building className="w-6 h-6 text-primary" />
                  <h2 className="text-xl font-semibold text-foreground">Retailer Information</h2>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="storeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Store Name</FormLabel>
                          <FormControl>
                            <Input placeholder="ABC Convenience Store" {...field} data-testid="input-store-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="buyerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Buyer Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Smith" {...field} data-testid="input-buyer-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="contactEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Buyer Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="john@abcstore.com" {...field} data-testid="input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="contactPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Buyer Phone</FormLabel>
                          <FormControl>
                            <Input type="tel" placeholder="(555) 123-4567" {...field} data-testid="input-phone" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="addr1"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address Line 1</FormLabel>
                          <FormControl>
                            <Input placeholder="123 Main Street" {...field} data-testid="input-address1" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="addr2"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address Line 2 (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="Suite 100" {...field} data-testid="input-address2" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input placeholder="Los Angeles" {...field} data-testid="input-city" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-2 gap-2">
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>State</FormLabel>
                              <FormControl>
                                <Input placeholder="CA" maxLength={2} {...field} data-testid="input-state" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="zip"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ZIP</FormLabel>
                              <FormControl>
                                <Input placeholder="90210" maxLength={10} {...field} data-testid="input-zip" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="paymentTerms"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Terms</FormLabel>
                          <FormControl>
                            <Input placeholder="Net 30" {...field} data-testid="input-payment-terms" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="retailerCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Retailer Code (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="ABC001" {...field} data-testid="input-retailer-code" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Product Catalog */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <Package className="w-6 h-6 text-primary" />
                    <h2 className="text-xl font-semibold text-foreground">Product Catalog</h2>
                  </div>
                  <Badge variant="secondary">Bulk Discounts Available</Badge>
                </div>

                {productsLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-muted rounded-lg h-48 mb-4"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-muted rounded w-3/4"></div>
                          <div className="h-3 bg-muted rounded w-1/2"></div>
                          <div className="h-4 bg-muted rounded w-1/3"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    {products?.map((product) => {
                      const quantity = quantities[product.sku] || 0;
                      const tierDiscount = getTierDiscount(product);
                      const currentPrice = tierDiscount ? parseFloat(tierDiscount.price) : parseFloat(product.basePrice);
                      
                      return (
                        <div 
                          key={product.sku} 
                          className={`bg-background border border-border rounded-lg p-4 hover:shadow-md transition-shadow ${tierDiscount ? 'tier-discount' : ''}`}
                          data-testid={`card-product-${product.sku}`}
                        >
                          <img 
                            src={product.imageUrl || "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"} 
                            alt={product.name}
                            className="w-full h-48 object-cover rounded-md mb-4" 
                          />
                          <h3 className="font-semibold text-lg text-foreground mb-2">{product.name}</h3>
                          <p className="text-muted-foreground text-sm mb-2">{product.description || 'Premium beverage product'}</p>
                          <p className="text-primary font-bold text-lg mb-1" data-testid={`text-price-${product.sku}`}>
                            ${currentPrice.toFixed(2)}
                          </p>
                          <p className="text-muted-foreground text-xs mb-4">{product.unit}</p>
                          
                          {product.tierPricing && Array.isArray(product.tierPricing) && (
                            <div className="bg-accent/50 rounded p-2 mb-4 text-xs">
                              <div className="font-medium mb-1">Tier Pricing:</div>
                              {(product.tierPricing as { minQuantity: number; price: string }[]).map((tier, index) => (
                                <div key={index}>
                                  {tier.minQuantity}+ units: ${tier.price} each
                                </div>
                              ))}
                            </div>
                          )}
                          
                          <div className="flex items-center justify-center space-x-3">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="min-w-11 min-h-11 w-11 h-11 p-0"
                              onClick={() => decrementQuantity(product.sku)}
                              disabled={quantity === 0}
                              data-testid={`button-decrease-${product.sku}`}
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                            <Input
                              type="number"
                              className="quantity-input w-16 text-center py-1"
                              value={quantity}
                              min="0"
                              max="999"
                              onChange={(e) => updateQuantity(product.sku, parseInt(e.target.value) || 0)}
                              data-testid={`input-quantity-${product.sku}`}
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="min-w-11 min-h-11 w-11 h-11 p-0"
                              onClick={() => incrementQuantity(product.sku)}
                              data-testid={`button-increase-${product.sku}`}
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                          </div>
                          
                          {tierDiscount && (
                            <div className="text-green-600 text-xs mt-2 text-center transition-opacity">
                              Tier discount applied!
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Order Summary */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <Calculator className="w-6 h-6 text-primary" />
                  <h2 className="text-xl font-semibold text-foreground">Order Summary</h2>
                </div>

                <div className="bg-background rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span className="font-semibold text-foreground" data-testid="text-subtotal">
                      ${(subtotal + discounts).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-muted-foreground">Tier Discounts:</span>
                    <span className="font-semibold text-green-600" data-testid="text-discounts">
                      -${discounts.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-border">
                    <span className="text-muted-foreground">Tax (8.25%):</span>
                    <span className="font-semibold text-foreground" data-testid="text-tax">
                      ${tax.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-t-2 border-primary">
                    <span className="text-lg font-bold text-foreground">Total:</span>
                    <span className="text-2xl font-bold text-primary" data-testid="text-total">
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="mt-6 flex flex-col sm:flex-row gap-4">
                  <Button 
                    type="button" 
                    variant="secondary" 
                    className="flex-1"
                    onClick={clearForm}
                    data-testid="button-clear-order"
                  >
                    Clear Order
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1"
                    disabled={submitOrderMutation.isPending}
                    data-testid="button-submit-order"
                  >
                    {submitOrderMutation.isPending ? "Submitting..." : "Submit Order"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Delivery Details */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Delivery Details (Optional)</h3>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="deliveryDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Delivery Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} data-testid="input-delivery-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="windowStart"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Window Start</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} data-testid="input-window-start" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="windowEnd"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Window End</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} data-testid="input-window-end" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="deliveryNotes"
                  render={({ field }) => (
                    <FormItem className="mt-4">
                      <FormLabel>Delivery Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any special instructions..." 
                          className="min-h-[80px]"
                          {...field} 
                          data-testid="textarea-delivery-notes"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

          </form>
        </Form>
      </main>
    </div>
  );
}
