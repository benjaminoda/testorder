import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Settings, Package, Image, Save, AlertCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

export default function AdminPage() {
  const { toast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);

  // Fetch products
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: async (data: { id: string; imageUrl: string }) => {
      const response = await fetch(`/api/products/${data.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ imageUrl: data.imageUrl }),
      });
      if (!response.ok) {
        throw new Error("Failed to update product");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: "Success",
        description: "Product image updated successfully.",
      });
      setSelectedProduct(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update product image.",
        variant: "destructive",
      });
    },
  });

  const handleImageUrlUpdate = (productId: string, imageUrl: string) => {
    updateProductMutation.mutate({ id: productId, imageUrl });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/3"></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-48 bg-muted rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <Settings className="w-8 h-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage products and system settings</p>
          </div>
        </div>

        <Tabs defaultValue="products" className="space-y-6">
          <TabsList>
            <TabsTrigger value="products" className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              Products
            </TabsTrigger>
            <TabsTrigger value="images" className="flex items-center gap-2">
              <Image className="w-4 h-4" />
              Image Management
            </TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Product Catalog
                </CardTitle>
                <CardDescription>
                  Manage your product catalog and pricing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products?.map((product) => (
                    <Card key={product.id} className="border-2">
                      <CardContent className="p-4">
                        <div className="aspect-video bg-muted rounded-lg mb-4 overflow-hidden">
                          {product.imageUrl ? (
                            <img
                              src={product.imageUrl}
                              alt={product.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                              <Image className="w-8 h-8" />
                            </div>
                          )}
                        </div>
                        <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{product.description}</p>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-lg font-bold text-primary">${product.basePrice}</span>
                          <Badge variant={product.active ? "default" : "secondary"}>
                            {product.active ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">SKU: {product.sku}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="images" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Image className="w-5 h-5" />
                  Product Image Management
                </CardTitle>
                <CardDescription>
                  Update product images by providing image URLs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {products?.map((product) => (
                    <ImageUploadCard
                      key={product.id}
                      product={product}
                      isSelected={selectedProduct === product.id}
                      onSelect={() => setSelectedProduct(product.id)}
                      onUpdateImage={handleImageUrlUpdate}
                      isUpdating={updateProductMutation.isPending}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

interface ImageUploadCardProps {
  product: Product;
  isSelected: boolean;
  onSelect: () => void;
  onUpdateImage: (productId: string, imageUrl: string) => void;
  isUpdating: boolean;
}

function ImageUploadCard({ product, isSelected, onSelect, onUpdateImage, isUpdating }: ImageUploadCardProps) {
  const [imageUrl, setImageUrl] = useState(product.imageUrl || '');
  const [previewUrl, setPreviewUrl] = useState(product.imageUrl || '');

  const handlePreview = () => {
    if (imageUrl.trim()) {
      setPreviewUrl(imageUrl.trim());
    }
  };

  const handleSave = () => {
    if (imageUrl.trim()) {
      onUpdateImage(product.id, imageUrl.trim());
    }
  };

  return (
    <Card className={`border-2 ${isSelected ? 'border-primary' : 'border-border'}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold">{product.name}</h3>
            <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
          </div>
          <Badge variant={product.imageUrl ? "default" : "outline"}>
            {product.imageUrl ? "Has Image" : "No Image"}
          </Badge>
        </div>

        <div className="aspect-video bg-muted rounded-lg mb-4 overflow-hidden">
          {previewUrl ? (
            <img
              src={previewUrl}
              alt={product.name}
              className="w-full h-full object-cover"
              onError={() => setPreviewUrl('')}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <Image className="w-8 h-8" />
            </div>
          )}
        </div>

        <div className="space-y-3">
          <div>
            <Label htmlFor={`imageUrl-${product.id}`}>Image URL</Label>
            <Input
              id={`imageUrl-${product.id}`}
              type="url"
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              data-testid={`input-image-url-${product.sku}`}
            />
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePreview}
              disabled={!imageUrl.trim()}
              data-testid={`button-preview-${product.sku}`}
            >
              Preview
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              disabled={!imageUrl.trim() || isUpdating}
              className="flex items-center gap-2"
              data-testid={`button-save-${product.sku}`}
            >
              {isUpdating ? (
                <AlertCircle className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Save
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}