# Google Sheets Backend Setup Guide

Follow these steps to set up the Google Sheets backend for your Easies Order Form:

## 1. Create Google Sheets

1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Rename it to "Easies Orders Database"
4. Create three tabs with the following names:
   - `Orders`
   - `OrderLines` 
   - `Accounts`
5. Copy the spreadsheet ID from the URL (it's the long string between `/d/` and `/edit`)

## 2. Deploy Google Apps Script

1. Go to [Google Apps Script](https://script.google.com)
2. Click "New Project"
3. Delete the default code and paste the contents from `Code.gs`
4. Update the configuration variables:
   ```javascript
   const ADMIN_KEY = "your-secure-admin-key"; // Choose a secure password
   const SPREADSHEET_ID = "your-google-sheets-id"; // From step 1
   ```
5. Save the project (Ctrl+S or Cmd+S)
6. Click "Deploy" → "New deployment"
7. Choose "Web app" as the type
8. Set execute as "Me" and access to "Anyone"
9. Click "Deploy" and authorize the app
10. Copy the deployment URL

## 3. Configure Environment Variables

Add these variables to your `.env` file:

```env
APPS_SCRIPT_URL=your-deployment-url-from-step-2
ADMIN_KEY=your-secure-admin-key-from-step-2
```

## 4. Test the Integration

1. Restart your application: `npm run dev`
2. Test the selftest endpoint: `curl http://localhost:5000/api/selftest`
3. You should see a response indicating Google Apps Script connectivity
4. Submit a test order through the web form
5. Check your Google Sheets to verify the order was recorded

## Sheet Structure

The Google Apps Script will automatically create the following structure:

### Orders Sheet
- OrderID, StoreID, StoreName, BuyerName, ContactEmail, ContactPhone
- Addr1, Addr2, City, State, ZIP, PaymentTerms, RetailerCode
- DeliveryDate, WindowStart, WindowEnd, DeliveryNotes, CreatedAt

### OrderLines Sheet  
- OrderID, SKU, ProductName, Quantity, UnitPrice, LineTotal

### Accounts Sheet
- Token, StoreID, StoreName, BuyerName, ContactEmail, ContactPhone
- Addr1, Addr2, City, State, ZIP, PaymentTerms, RetailerCode

## Features

- **Automatic Order Storage**: All orders are saved to Google Sheets
- **Account Management**: Customer information is stored for future prefills
- **Token-based Prefill**: Customers can use URLs with tokens to prefill their information
- **Order Line Items**: Detailed breakdown of each order with individual products
- **Secure Access**: Admin key protects the API endpoints

## Troubleshooting

- **403 Unauthorized**: Check that your ADMIN_KEY matches in both files
- **404 Spreadsheet not found**: Verify the SPREADSHEET_ID is correct
- **Apps Script errors**: Check the execution logs in Google Apps Script console
- **Selftest fails**: Ensure the deployment URL is correct and the web app is deployed as "Anyone" access