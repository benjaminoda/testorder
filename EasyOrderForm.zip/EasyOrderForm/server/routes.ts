import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema } from "@shared/schema";
import { z } from "zod";

// Environment variables with fallbacks
const APPS_SCRIPT_URL = process.env.APPS_SCRIPT_URL || process.env.VITE_APPS_SCRIPT_URL || '';
const ADMIN_KEY = process.env.ADMIN_KEY || process.env.VITE_ADMIN_KEY || '';

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check endpoint
  app.get('/api/ping', (req, res) => {
    return res.json({ ok: true, ts: new Date().toISOString() });
  });

  // Selftest endpoint - proxy to Google Apps Script
  app.get('/api/selftest', async (req, res) => {
    if (!APPS_SCRIPT_URL) {
      return res.json({ 
        ok: true, 
        selftest: 'local-only', 
        timestamp: new Date().toISOString(),
        message: 'Google Apps Script not configured. Orders are saved to local database only.',
        status: 'database-only'
      });
    }

    try {
      let url = APPS_SCRIPT_URL + '?action=ping';
      if (ADMIN_KEY) {
        url += '&key=' + encodeURIComponent(ADMIN_KEY);
      }

      const gsRes = await fetch(url);
      const status = gsRes.status;
      
      if (!gsRes.ok) {
        const errorText = await gsRes.text();
        return res.status(status).send(errorText || 'Apps Script responded with an error.');
      }

      try {
        const data = await gsRes.json();
        return res.json(data);
      } catch (parseErr) {
        const text = await gsRes.text();
        const contentType = gsRes.headers.get('content-type') || '';
        res.set('content-type', contentType.includes('application/json') ? 'application/json' : 'text/plain');
        return res.send(text);
      }
    } catch (err) {
      console.error('Error in /api/selftest:', err);
      return res.status(500).json({ ok: false, error: 'Selftest proxy error', details: (err as Error).toString() });
    }
  });

  // Prefill endpoint - proxy to Google Apps Script
  app.get('/api/prefill', async (req, res) => {
    const token = req.query.t;
    if (!token) {
      return res.status(400).json({ ok: false, error: 'Missing token parameter' });
    }

    if (!APPS_SCRIPT_URL) {
      return res.json({ 
        message: 'Token-based prefill requires Google Sheets integration. See google-apps-script/SETUP.md for instructions.' 
      });
    }

    try {
      let url = APPS_SCRIPT_URL + '?action=prefill&t=' + encodeURIComponent(token as string);
      if (ADMIN_KEY) {
        url += '&key=' + encodeURIComponent(ADMIN_KEY);
      }

      const gsRes = await fetch(url);
      const status = gsRes.status;
      
      if (!gsRes.ok) {
        const errorText = await gsRes.text();
        return res.status(status).send(errorText || 'Apps Script prefill error.');
      }

      try {
        const data = await gsRes.json();
        return res.json(data);
      } catch (parseErr) {
        const text = await gsRes.text();
        return res.send(text);
      }
    } catch (err) {
      console.error('Error in /api/prefill:', err);
      return res.status(500).json({ ok: false, error: 'Prefill proxy error', details: (err as Error).toString() });
    }
  });

  // Get products endpoint
  app.get('/api/products', async (req, res) => {
    try {
      const products = await storage.getProducts();
      return res.json(products);
    } catch (err) {
      console.error('Error fetching products:', err);
      return res.status(500).json({ ok: false, error: 'Failed to fetch products' });
    }
  });

  // Update product endpoint
  app.put('/api/products/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedProduct = await storage.updateProduct(id, updates);
      if (!updatedProduct) {
        return res.status(404).json({ error: 'Product not found' });
      }
      
      res.json(updatedProduct);
    } catch (err) {
      console.error('Error updating product:', err);
      res.status(500).json({ error: 'Failed to update product' });
    }
  });

  // Order submission endpoint
  app.post('/api/order/submit', async (req, res) => {
    try {
      // Validate the request body
      const orderData = insertOrderSchema.parse(req.body);

      // If Apps Script URL is configured, forward to Google Apps Script
      if (APPS_SCRIPT_URL) {
        try {
          let url = APPS_SCRIPT_URL;
          if (ADMIN_KEY) {
            url += (url.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(ADMIN_KEY);
          }

          // Transform the data to match Google Apps Script expected format
          const flattenedData = {
            orderId: orderData.orderId,
            storeId: orderData.storeId,
            storeName: orderData.storeName,
            buyerName: orderData.buyerName,
            contactEmail: orderData.contactEmail,
            contactPhone: orderData.contactPhone,
            addr1: orderData.addr1,
            addr2: orderData.addr2,
            city: orderData.city,
            state: orderData.state,
            zip: orderData.zip,
            paymentTerms: orderData.paymentTerms,
            retailerCode: orderData.retailerCode,
            deliveryDate: orderData.deliveryDate,
            windowStart: orderData.windowStart,
            windowEnd: orderData.windowEnd,
            deliveryNotes: orderData.deliveryNotes,
            items: orderData.items,
            subtotal: orderData.subtotal,
            tax: orderData.tax,
            total: orderData.total,
            totalTrays: orderData.totalTrays,
            channel: orderData.channel || 'Web-Form'
          };

          const gsRes = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain' },
            body: JSON.stringify(flattenedData)
          });

          const status = gsRes.status;
          if (!gsRes.ok) {
            const errorText = await gsRes.text();
            console.warn('Google Apps Script error:', errorText);
            // Fall through to local storage
          } else {
            try {
              const responseData = await gsRes.json();
              return res.json({ 
                ...responseData,
                integration: 'sheets'
              });
            } catch (parseErr) {
              const text = await gsRes.text();
              if (text) {
                return res.json({ 
                  ok: true, 
                  message: text,
                  integration: 'sheets'
                });
              } else {
                return res.json({ 
                  ok: true,
                  integration: 'sheets'
                });
              }
            }
          }
        } catch (err) {
          console.error('Google Apps Script error:', err);
          // Fall through to local storage
        }
      }

      // Store order locally and generate order ID
      const order = await storage.createOrder(orderData);
      const orderId = orderData.storeId || (orderData.storeName.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12) + '-' + orderData.zip);
      
      return res.json({ 
        ok: true, 
        orderId: orderId,
        message: 'Order received and will be processed within 24 hours.',
        integration: 'local'
      });

    } catch (err) {
      console.error('Error submitting order:', err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({ ok: false, error: 'Validation error', details: err.errors });
      }
      return res.status(500).json({ ok: false, error: 'Order submission failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
