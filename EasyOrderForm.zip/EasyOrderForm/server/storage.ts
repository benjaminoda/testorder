import { type Order, type InsertOrder, type Product, type InsertProduct, orders, products } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  getProducts(): Promise<Product[]>;
  getProduct(sku: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, updates: Partial<Product>): Promise<Product | null>;
}

export class DatabaseStorage implements IStorage {
  async getOrder(id: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.active, 1));
  }

  async getProduct(sku: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.sku, sku));
    return product || undefined;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
    const [updatedProduct] = await db
      .update(products)
      .set(updates)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct || null;
  }

  async initializeProducts(): Promise<void> {
    // Check if products already exist
    const existingProducts = await this.getProducts();
    if (existingProducts.length > 0) return;

    const defaultProducts: InsertProduct[] = [
      {
        sku: "VAR-8PK-TRAY",
        name: "Variety Pack",
        description: "8-pack tray with assorted flavors",
        basePrice: "24.99",
        unit: "per 8-pack tray",
        tierPricing: [
          { minQuantity: 5, price: "22.99" },
          { minQuantity: 10, price: "20.99" }
        ],
        active: 1
      },
      {
        sku: "PM-12PK-BOX",
        name: "Perfect Morning",
        description: "12-pack box premium morning blend",
        basePrice: "36.99",
        unit: "per 12-pack box",
        tierPricing: [
          { minQuantity: 3, price: "34.99" },
          { minQuantity: 6, price: "32.99" }
        ],
        active: 1
      },
      {
        sku: "BM-6PK-BOTTLE",
        name: "Blue Moon",
        description: "6-pack bottle evening blend",
        basePrice: "18.99",
        unit: "per 6-pack bottle",
        tierPricing: [
          { minQuantity: 4, price: "17.99" },
          { minQuantity: 8, price: "16.99" }
        ],
        active: 1
      },
      {
        sku: "HC-4PK-CAN",
        name: "Hard Coffee",
        description: "4-pack can premium hard coffee",
        basePrice: "15.99",
        unit: "per 4-pack can",
        tierPricing: [
          { minQuantity: 6, price: "14.99" },
          { minQuantity: 12, price: "13.99" }
        ],
        active: 1
      }
    ];

    // Insert all default products
    await db.insert(products).values(defaultProducts);
  }
}

const storage = new DatabaseStorage();

// Initialize products on startup
storage.initializeProducts().catch(console.error);

export { storage };
